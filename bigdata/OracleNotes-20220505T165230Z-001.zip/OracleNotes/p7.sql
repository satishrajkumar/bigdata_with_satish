/*
  This plsql block reads two values from key board into n1 
  and n2, performs comparision between them
*/
declare
  n1 number(4);
  n2 number(4);
begin
  n1:=&n1;
  n2:=&n2;
  if n1 > n2 then
     dbms_output.put_line(n1 || ' is greater than ' || n2);
  elsif n1 < n2 then
      dbms_output.put_line(n1 || ' is less than ' || n2);
  else
      dbms_output.put_line(n1 || ' is equal to ' || n2);
  end if;
  
end;
/

       
