declare
  n1 number(4);
  n2 number(4);
  result number(4);
begin
  n1:='&n1';
  n2:='&n2';
  result:=n1 + n2;
  dbms_output.put_line('Sum of ' || n1 || ' and ' || n2 || 
                        ' = ' || result);
end;
/