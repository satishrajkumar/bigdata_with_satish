BEGIN
  DBMS_OUTPUT.PUT_LINE('Welcome to PLSQL Programmig');
END;
/