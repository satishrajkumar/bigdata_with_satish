--------------------------------------------------------
--  File created - Monday-December-27-2021   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure P_CALC_WAGES
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "SCOTT"."P_CALC_WAGES" 
(
  P_ENO IN NUMBER 
) AS 
  V_ENO NUMBER(6);
  V_ENAME VARCHAR2(20);
  V_BASIC NUMBER(9,2);
  V_HRA NUMBER(9,2);
  V_TSAL NUMBER(9,2);
BEGIN
  SELECT ENO,ENAME,BASIC INTO V_ENO,V_ENAME,V_BASIC FROM EMP_WAGES
    WHERE ENO=P_ENO;
    
  IF V_BASIC >= 50000 THEN
     V_HRA:=V_BASIC * .2;
  ELSIF V_BASIC >= 25000 THEN
     V_HRA:=V_BASIC * .1;
  ELSE
     V_HRA:=2000;
  END IF;
  
  V_TSAL:=V_BASIC + V_HRA;
  
  UPDATE EMP_WAGES SET HRA=V_HRA, TSAL=V_TSAL
     WHERE ENO=P_ENO;
  DBMS_OUTPUT.PUT_LINE('ONE EMPLOY SALARY IS CALCULATED AND POSTED');   
    
END P_CALC_WAGES;

/
