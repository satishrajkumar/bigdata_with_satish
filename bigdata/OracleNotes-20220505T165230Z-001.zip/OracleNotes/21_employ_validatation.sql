REM It is to implement validations on employ table 

/*
  Application Title	:	Payroll
  Developer Name	:	Srinivasa Omprakash
  Developed Date	:	13-dec-21
  Version		:	1.0
*/

prompt Adding primary key on ENO column of EMPLOY table ...
alter table employ add
  constraint emp_eno_pk primary key(eno);

prompt adding not null constraints on columns of EMPLOY table ...
alter table employ modify
  (ename constraint emp_enam_nn not null,
   gender constraint emp_gend_nn not null
  );
  
prompt adding check constraint on gender column of EMPLOY table ...
alter table employ add
   constraint emp_gend_ck check(gender='M' or gender='F');

prompt adding check constraint on salary column of EMPLOY table ...
alter table employ add
   constraint emp_sal_ck check(salary between 10000 and 50000);


