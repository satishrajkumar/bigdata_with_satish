/*
  This plsql block reads two numbers from keyboard 
  and find out both are equal or inequal 
*/
declare
  n1 number(4);
  n2 number(4);
begin
  n1:=&n1;
  n2:=&n2;
  if n1 = n2 then
    dbms_output.put_line(n1 || ' is equal to ' || n2);
  else
    dbms_output.put_line(n1 || ' is not equal to ' || n2);
  end if;
end;
/