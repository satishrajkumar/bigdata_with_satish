/*
  This plsql block demonstrates the concept of repeatedly
  executing a set of statements with looping concept
*/

declare
  i number(2);
  j number(2);
begin
  dbms_output.put_line('While loop prints first 5 numbers');
  i:=1;
  while i <= 5 loop
    dbms_output.put_line(i);
    i:=i + 1;
  end loop;

  dbms_output.put_line('Output from loop end loop');
  j:=1;
  loop
    dbms_output.put_line(j);
    j:=j + 1;
    exit when j > 5;
  end loop;

  dbms_output.put_line('For loop displays first 5 numbers');
  for k in 1 .. 5 loop
    dbms_output.put_line(k);
  end loop;

  dbms_output.put_line('For loop displays first 5 numbers in reverse order');
  for k in reverse 1 .. 5 loop
    dbms_output.put_line(k);
  end loop;
end;
/
