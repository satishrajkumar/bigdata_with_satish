--------------------------------------------------------
--  File created - Monday-December-27-2021   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure P_WELCOME1
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "SCOTT"."P_WELCOME1" 
(
  P_NAME IN VARCHAR2 
) AS 
BEGIN
  DBMS_OUTPUT.PUT_LINE('WELCOME TO ' || p_name);
END P_WELCOME1;

/
