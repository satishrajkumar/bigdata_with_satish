/* 
  This plsql block say Hi to Srinivasa Omprakash 
  and also display his current location
*/
DECLARE   -- declaration section
  NAME VARCHAR2(30);
  LOCATION VARCHAR2(30):='INDIA';  -- Initialization of a variable
BEGIN   -- Executable section
  NAME:='Srinivasa Omprakash';   -- Assigning a value to variable 
  DBMS_OUTPUT.PUT_LINE('Hi ' || NAME);
  dbms_output.put_line('He is currenlty staying in ' || Location);
END;
/
