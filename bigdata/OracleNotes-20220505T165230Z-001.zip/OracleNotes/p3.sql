/*
  This plsql block reads first name and last name from key board and
  display full name 
*/

declare
 first_name varchar2(30);
 last_name varchar2(30);
 full_name varchar2(60);
begin
 first_name:='&first_name';
 last_name:='&last_name';
 full_name:=first_name || ' ' || last_name;
 dbms_output.put_line(full_name);
end;
/
 