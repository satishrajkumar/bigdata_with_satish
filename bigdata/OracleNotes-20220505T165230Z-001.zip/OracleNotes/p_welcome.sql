create or replace procedure p_welcome
as
begin
  dbms_output.put_line('welcome to plsql programming');
end;
/